# Stark Holo Keyboard V2

A browser-based Iron Man-inspired holographic keyboard with webcam hand tracking.

## Run
1. Extract the ZIP.
2. Open a local server in the project folder, for example:
   `python -m http.server 8000`
3. Open `http://localhost:8000` in Chrome/Edge.
4. Allow camera permission.
5. Click START CAMERA.
6. Point with your index finger. Pinch thumb + index to press.

## Notes
- This is a visual/functional holographic-style UI, not a physical floating hologram.
- Camera access normally requires HTTPS or localhost.
- MediaPipe model files load from Google's CDN.
- Physical keyboard input also works.
